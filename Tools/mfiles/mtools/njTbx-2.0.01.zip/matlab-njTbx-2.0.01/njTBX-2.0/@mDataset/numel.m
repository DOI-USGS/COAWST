function result = numel(varargin)

% mDataset/numel -- Overloaded NUMEL.

result = 1;