% JAVA_ISOSURFACE_DEMO - Read 3D field from CF-1.0 Compatible File and plot as isosurface
% 
% 
% rsignell@usgs.gov
% Sachin Kumar Bhate (skbhate@ngi.msstate.edu)


% Inputs
var = 'temp';                 % variable to read
iTime = 1;                    % read 1st timestep 
%
% File or URL
%uri = 'http://stellwagen.er.usgs.gov/cgi-bin/nph-dods/models/adria/roms_sed/bora_feb.nc';% NetCDF or OpenDAP file
%uri = 'c:\rps\cf\venice\feb_bora2.nc';% NetCDF or OpenDAP file
%iso_value = 14.5;            % isosurface value to plot 

% UMASS Boston ECOM model
%uri='http://stellwagen.er.usgs.gov/models/test/umassb_ecom.ncml';
%iso_value = 7.0;             % isosurface value 

% UMAINE POM Model
%uri='c:/rps/cf/gomoos/umaine_agg.ncml';
%uri='http://stellwagen.er.usgs.gov/models/test/umaine_pom.ncml'
iso_value = 8.2;             % isosurface value 

% WHOI ROMS Model
uri='http://science.whoi.edu/users/kestons/redtide_2005_hindcast/OUT/avg_gom_0014.nc';
iso_value = 8.2;

try 
    % open CF-compliant NetCDF File as a Common Data Model (CDM) "Grid Dataset"
    nc = mDataset(uri);  % mDataset object
    
    % get the geogrid object 
    GeoGridVar = getGeoGridVar(nc,var);  %mGeoGridVar object
    
    % get access to coordinate system;
    GridCoordSys = getCoordSys(GeoGridVar);  %mGridCoordinates object    
      
    %get time data
    timeDate = getTimes(GridCoordSys);
    
    % get coordinate axes        
    lat=getLatAxis(GridCoordSys);
    lon=getLonAxis(GridCoordSys);
    
    % vertical coordinates for specified time step
    z = getVerticalAxis(GridCoordSys,iTime); %  
   
    % read the volume data at given time index(3D)
    data = getData(GeoGridVar, iTime);
    
    %cleanup
    nc.close();
    clear nc;
    clear GeoGridVar;
    clear GridCoordSys;
    
catch
    %gets the last error generated 
    err = lasterror();    
    disp(err.message); 
end
    

% plot stuff
% plot min z level (~=water depth)
h=squeeze(min(z)); % plot minimum z level
surf(lon,lat,h,'FaceColor',[0.7 0.7 0.7],'EdgeColor','none');

% plot isosurface
[nz,ny,nx]=size(data);
lon3d=permute(repmat(lon,[1 1 nz]),[3 1 2]);
lat3d=permute(repmat(lat,[1 1 nz]),[3 1 2]);
data(data==0)=nan;
p = patch(isosurface(lon3d,lat3d,z,data,iso_value));
set(p, 'FaceColor', [0 1 1], 'EdgeColor', 'none');
daspect([1 cos(mean(lat(:)*pi/180)) 400]);
% set the view
view(0,45);

%zoom(1.8);
% set lighting
camlight; lighting phong
% use date string for title
title(datestr(timeDate(iTime)));  % 

figure(gcf);
%load('../adriatic/coast5.mat');
%line(coast(:,1),coast(:,2),'color','black');

