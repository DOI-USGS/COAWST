function result = subsref(mGeoGridVarObj, theStruct)

% mGeoGridVar/subsref -- Overloaded "{}", "()", and "." operators.
%  subsref(this, theStruct) processes subscripting references
%   of this, a "mGeoGridVar" object.

% Sachin Kumar Bhate (skbhate@ngi.msstate.edu) (C) 2008
% Mississippi State University

if nargin < 2, help(mfilename), return, end

result = [];
if (~isa(mGeoGridVarObj, 'mGeoGridVar'))    
    error('MATLAB:mGeoGridVar:subsref',...
       'Invalid Object "%s".', class(mGeoGridVarObj));                    
end
%check for empty index
if length(theStruct) < 1
	result = mGeoGridVarObj;	
	return
end

s = theStruct;
theType = s(1).type;
theSubs = s(1).subs;
s(1) = [];

% the sub can be a cell array ..but we need the value.

if isa(theSubs, 'char')  
   mySub = theSubs;
end
myShape =  getShape(mGeoGridVarObj);

    switch theType
        % DOT reference
          case '.'
            switch mySub            
                case 'getAttributes'            
                    result = getAttributes(mGeoGridVarObj);           
                case 'getShape'            
                    result = myShape;
                case 'getCoordSys'            
                    result = getCoordSys(mGeoGridVarObj);    
                otherwise
                    error('Method "%s" not accessible with "dot" reference.', mySub);
            end  
        %cell reference
          case '()'              
               if ~isempty(myShape)
                [start count stride] = parseIndices(theSubs, myShape); 
                subGridObj=njSubsetGrid(mGeoGridVarObj,start,count,stride);
                origGeoGridVarStruct = struct(mGeoGridVarObj);
                %create a substruct
                subGeoGridVarStruct.myNCid = origGeoGridVarStruct.myNCid;
                subGeoGridVarStruct.myGridID = subGridObj;  %subset JGeoGridDataset object
                subGeoGridVarStruct.myVarID = origGeoGridVarStruct.myVarID;
                subGeoGridVarStruct.varName = origGeoGridVarStruct.varName;
                subGeoGridVarStruct.myShape = double(transpose(subGridObj.getGeoGrid.getShape));
                
                result=class(subGeoGridVarStruct,'mGeoGridVar');  %create mGeoGridVar object               
                 
               else
                    result = [];               
                    disp('No dimensions associated with variable');
                end     


        otherwise,
            warning('MATLAB:subsref', ...
                             'Invalid index type, "%s".', theType)
    end
end
   



