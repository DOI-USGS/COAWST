function [start,stop]=cf_time_index(uri,var,start_time,stop_time)
% CF_TIME_INDEX - Get indexes for time coordinate variable.
%
% Usage:
%   [start,stop]=cf_time_index(uri,var,start_time,[stop_time])
% where,
%   uri - CF-compliant NetCDF, OpenDAP or NCML file
%         var - variable whose time dimension to get indices from
%         start_time - start time  %matlab datenum
%         stop_time - end time     % matlab datenum
% returns,           
%   start  - index for specified start_time. '-1' if no index found.
%   stop   - index for specified stop_time. '-1' if no index found.     
%
% e.g,
%   uri ='http://stellwagen.er.usgs.gov/cgi-bin/nph-dods/models/adria/roms_sed/bora_feb.nc';% NetCDF/OpenDAP/NcML file
%   [start,stop]=cf_time_index(uri,'temp','11-Feb-2003 12:00:00','15-Feb-2003 23:00:00')  % start and stop date is UTC/GMT
%
%
%Sachin Kumar Bhate (skbhate@ngi.msstate.edu) (c) 2008
%Mississippi State University.
%
% import the NetCDF-Java methods 
import msstate.cstm.data.JDataset
import msstate.cstm.data.grid.JGeoGridDataset
import msstate.cstm.util.JTime

import java.util.Date

    
if nargin < 3 
    disp('Check input arguments!')
    help cf_time_index
    return
end

%initialize
%start and stop index. '0' if time not present.
start = -1;
stop = -1; 

try 
    
    GridData = JDataset(uri);
    GeoGridData = JGeoGridDataset(GridData.getGridDataset(),var);     
    % get the coordinate system for this grid:
    GridCoordSys = GeoGridData.getCoordinateSystem();    
    
      %check if specified variable has time coordinate, and can be expressed
     %as a Date
    if ( GridCoordSys.hasTimeAxis() && GridCoordSys.isDate() ) 
        %create java date object from matlab date
        my_start_time = datestr(datenum(start_time));
        startDate = JTime.setCal(my_start_time);
        start = GridCoordSys.findTimeIndexFromDate(startDate) + 1;
        if nargin==4,
          my_stop_time = datestr(datenum(stop_time));
          stopDate = JTime.setCal(my_stop_time);
          stop = GridCoordSys.findTimeIndexFromDate(stopDate) + 1;               
        end
    else
        disp(sprintf('\nWarning: No coordinate values found with specified variable "%s".', var));       
    end 
    %cleanup
    GridData.close();
catch
    %gets the last error generated 
    err = lasterror();    
    disp(err.message); 
end 
   

