% function []=grid2;
% GRIDTOP puts a grid on top of the current axes
set(gca,'xgrid','on','ygrid','on','layer','top');    
