%   Miscellaneous time series manipulation and analysis tools from (mostly)
%   Rich Signell
%
