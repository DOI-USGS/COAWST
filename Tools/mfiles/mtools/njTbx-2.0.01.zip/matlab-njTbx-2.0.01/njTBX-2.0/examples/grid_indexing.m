% Apply matlab subscripting reference on geogrid to retrieve data and grid
% in a gridData object.

uri_grd='http://www.gri.msstate.edu/rsearch_data/nopp/bora_feb.nc';
var='temp';
%get mDataset object
nc=mDataset(uri_grd);
%get geogrid
geog=getGeoGridVar(nc,var);
%use array indexing to subset grid. 
%It returns a subsampled geogrid var object
subgeog=geog(1:3,1:3,2:10,2:2:end);  %shape[8 20 60 160]

%get the data and grid from the geogrid  object
data=getData(subgeog); 
grd=getGrid(subgeog);

close(nc);
clear nc;


