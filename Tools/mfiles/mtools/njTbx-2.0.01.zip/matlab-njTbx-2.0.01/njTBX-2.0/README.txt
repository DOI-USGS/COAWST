README: njTBX-2.0 (beta)

Disclaimer: This is a development directory and code is still being tested.

Matlab Object API to access netcdf data using netcdf-Java API.
Based on Matlab Object paradigm supported by version version 2008a. The earlier
versions of OOP are forward compatible. So can be used with 2008a as well.
 
Requirement:

1. Matlab version 2008a and earlier.
2. njTools Java API vesion 2.0
3. Unidata's Necdf-Java API Version 4.0 (toolsUI-4.0-skb<version>.jar) 
4. Java version 1.6 or higher
   

any questions..
send email to skbhate@ngi.msstate.edu

-Sachin Bhate.
skbhate@ngi.msstate.edu
Copyright Mississippi State University

   

