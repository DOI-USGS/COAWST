% TEST_PLOT2D_FVCOM - Script to plot 2d elevation field for fvcom data.
%
% Rich Signell (rsignell@usgs.gov)

uri='http://fvcom.smast.umassd.edu/Data/netcdf_java.nc';
%uri='http://stellwagen.er.usgs.gov/models/test/fvcom2.nc';

% read 1st time step of 2D elevation field

[zeta,zeta_grd] = cf_grid_varget(uri,'zeta',[1,1,1],[1,inf,inf]);
% read connectivity array
nv=nj_varget(uri,'nv');

% plot it up
trisurf(nv.',zeta_grd.lon,zeta_grd.lat,zeta);
caxis([-1 1]);view(2);
set(gca,'DataAspectRatio',[1 .74 1]);
title(['FVCOM zeta at: ' datestr(zeta_grd.time)]);
%shading('flat');
colorbar
figure(gcf);
