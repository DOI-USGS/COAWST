function [ncObj varObj] = testOOP(uri,var,type)

% Create higher level matlab objects. 
% 
% Usage:
% [ncObj varObj] = testOOP(uri,var,type)
% uri - any netcdf URI
% var - variable name
% type (optional) - specify 'grid' to get a 'geoGrid' matlab object 
%                   instead of plain netcdf variable matlab object.
%                   Default is 'matlab variable object'
%
%  [ncObj varObj] = testOOP(uri,var)  - will create 'mDataset' and 'mVariable' objects
%  [ncObj varObj] = testOOP(uri,var,'grid') - will create 'mDataset' and 'mGeoGrid' object
%
% Example datasets
%
% gridded dataset
%uri_grd='http://www.gri.msstate.edu/rsearch_data/nopp/bora_feb.nc';
%
% non-gridded dataset
%uri_nongrd='http://ourocean.jpl.nasa.gov:8080/thredds/dodsC/las/SCBfcst/scb_latest_fcst_roms.nc';
%uri_ncml='C:\skbhate\dev\usgs\matlab\data\roms_europe_wrkshp\scb_fcst_roms_jpl.ncml';
% uri_grd_thredds='http://coast-enviro.er.usgs.gov/thredds/dodsC/roms/rect/jpl/scb/fcst';

%var='temp';
%
%Array indexing
%Data can be accessed by using matlab subscripting references with
%'mVariable' object.
%e.g.
%varData = varobj(1,20,1:60,1:160);
%varData = varobj(1,20,1:60,1:end);
%
%Also, user can directly access the variable data from netcdf data object(mDataset)
%without creating variable object.
%e.g.
%varData = ncObj{'temp'}(1,20,1:60,1:end);
%
% Sachin Kumar Bhate (skbhate@ngi.msstate.edu)  (C) 2008
% Mississippi State University


if nargin < 1, help(mfilename), return, end
disp('Testing object "mDataset" ....');
disp(' ');

ncObj=mDataset(uri);  % get the netcdf dataset object

if (isa(ncObj, 'mDataset'))
    disp('mDataset object...... OK.');
    disp(ncObj);
else
    error('MATLAB:mDataset',...
        'Could not create mDataset object');
end

switch nargin
    case 2
        disp(sprintf('Testing object "mVar" for variable "%s".', var));
        disp(' ');
       % varObj=ncObj{var}; %subsref
        %or
        varObj=getVar(ncObj, var);  

        if (isa(varObj, 'mVar'))
            disp('mVar object...... OK.');
            disp(varObj);
        else
            error('MATLAB:mVar',...
                'Could not create mVar object');
        end
        
    case 3
        disp(sprintf('Testing object "mGeoGridVar" for variable "%s".', var));
        disp(' ');
        
        varObj=getGeoGridVar(ncObj,var);  %pass by value

        if (isa(varObj, 'mGeoGridVar'))
            disp('mGeoGridVar object...... OK.');
            disp(varObj);
        else
            error('MATLAB:mGeoGridVar',...
                'Could not create GeoGrid object');
        end
    otherwise
        return
end


end
