% Load parameters for test purpose

%Native netcdf data / non CF compliant /non-CDM 
uri_nongrd='http://ourocean.jpl.nasa.gov:8080/thredds/dodsC/las/SCBfcst/scb_latest_fcst_roms.nc';

%ncml
uri_ncml='C:\skbhate\dev\usgs\matlab\data\roms_europe_wrkshp\scb_fcst_roms_jpl.ncml';

%Thredds. CF-compliant 
uri_grd_thredds='http://coast-enviro.er.usgs.gov/thredds/dodsC/roms/rect/jpl/scb/fcst';

%http access.  CF -compliant
uri_grd_roms='http://www.gri.msstate.edu/rsearch_data/nopp/bora_feb.nc';

var='temp';
