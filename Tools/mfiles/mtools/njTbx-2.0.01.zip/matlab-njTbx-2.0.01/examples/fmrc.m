%Forecast Model Run Collection
uri='http://omglnx1.meas.ncsu.edu:8080/thredds/dodsC/fmrc/sabgom/SABGOM_Forecast_Model_Run_Collection_best.ncd';
[t,g]=cf_tslice(uri,'temp',1,1); % 1 is bottom level in ROMS
surf(g.lon,g.lat,g.z,double(t));