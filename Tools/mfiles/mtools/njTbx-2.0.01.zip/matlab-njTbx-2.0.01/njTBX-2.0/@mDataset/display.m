function display(mDatasetObj)

%mDataset/display - Display the content of mDataset Obj.
 
%Sachin Kumar Bhate (skbhate@ngi.msstate.edu)

    if nargin < 1, help(mfilename), return, end


    if nargin < 2
    % assign 'ans' if inputname(1) empty
        displayName = inputname(1);
        if isempty(displayName)
            displayName = 'ans';
        end
    end
    myClass = class(mDatasetObj);

    switch myClass
        case 'mDataset'
            mData = struct(mDatasetObj);
            dispStruct = struct( ...
                                'URI', mData.myName, ...
                                'numGrids', mData.mynGrid, ...
                                'numDimensions', mData.mynDim, ...
                                'numVariables', mData.mynVar ...
                                );
            
            
            disp(' '), disp([displayName ' =']), disp(' ')                
            disp(dispStruct);

        otherwise,
                warning('MATLAB:display', ...
                'Invalid Object, "%s".', myClass)
    end

end
