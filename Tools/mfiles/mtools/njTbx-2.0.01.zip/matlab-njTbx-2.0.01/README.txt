README: njTBX-2.0 (beta)

Disclaimer: This is a development directory and code is still being tested.

subversion access: http://svn1.hosted-projects.com/cmgsoft/m_cmg/trunk/njTools/release/beta/2.0  njTools-2.0

Matlab Object API to access netcdf data using netcdf-Java API.
Based on Matlab Object paradigm supported by version version 2008a. The earlier
versions of OOP are forward compatible. So can be used with 2008a as well.
 
Requirement:

1. Matlab version 2008a and earlier.
2. njTools Java API vesion 2.0
3. Unidata's Necdf-Java API Version 4.0 (toolsUI-4.0-skb<version>.jar) 
4. Java version 1.6 or higher

Setting up Matlab to work with NetCDF-Java and the NJ Toolbox:


Step 1: Set up Matlab to work with NetCDF-Java:

    * Get our version of Unidata's NetCDF-Java library: toolsUI-4.0-skb0.3.jar(~15 MB) and save it on your computer.  
       Current version: http://www.gri.msstate.edu/rsearch_data/nopp/njTools/njTools-2.0/toolsUI-4.0-skb0.3.jar

    * Get our njTools Java library: njTools-2.0.04.jar (~5 MB) and save it to your computer.
      Current version: http://www.gri.msstate.edu/rsearch_data/nopp/njTools/njTools-2.0/njTools-2.0.04.jar

    * If your browser saves it with a .zip extension, just rename it back to .jar after you have downloaded it.

      For Matlab 7+:   In Matlab, type "edit startup.m" and add the following lines (modified  for the actual location of your jar files):

      javaaddpath('c:\your_path_here\toolsUI-4.0-skb0.3.jar','-end');
      javaaddpath('c:\your_path_here\njTools-2.0.04.jar','-end');

    * For Matlab 6 or 6.5: Type "edit classpath.txt" in Matlab, add the jar files to the list
    * IMPORTANT: Remove any other older version  references to 'toolsUI.jar' and 'njTools.jar'    

Step 2: If you have Matlab 2008a or older, fix Matlab's java classpath:

    * In Matlab, type "edit classpath.txt" and delete this line
      $matlabroot/java/jarext/mwucarunits.jar 
      and save your changes.  For Linux users: If you can't edit the system classpath.txt file, then copy it to your home directory and make the edit there.  
       Matlab looks first for classpath.txt in your home directory, so it will use your edited version.    
    * (Worried that you just commented out some java methods used by the system?  Don't be.  It's confirmed with Mathworks that  mwucarunits.jar was a vestige 
      of testing in a much earlier version and actually was not being used by any Mathworks supplied routines.  They have removed it from the path in 2008b and higher.)

Step 3: Exit and Restart Matlab.  If you type "javaclasspath" you should see the two jar files you added
           (along with all the Java stuff that comes with Matlab)

Step 4: Set up Matlab to work with our NJ Toolbox:
   
    * The directory structure of NJ toolbox (After svn download)
       
       /njTBX-2.0: Matlab object API based on njTools and Unidata's netcdf-java API
       /njFunc: Useful matlab functions using njTBX-2.0, which also demonstrates use of njTBX-2.0 API.
       /examples: Examples/demos based on matlab functions in /njFunc.
      
       In order for examples to properly work, it is required that you also download directories 'seawater' and 'RPSstuff',  
       which contains helpful matlab functions. If you already have the directories (from earlier versions of njTools) you can 
       use your existing ones. The svn (subversion) access to 'seawater' and 'RPSstuff' is as shown below.

       1. RPSstuff: svn co http://svn1.hosted-projects.com/cmgsoft/m_cmg/trunk/RPSstuff  RPSstuff        	
       
       2. seawater:  svn co http://svn1.hosted-projects.com/cmgsoft/m_contrib/trunk/seawater  seawater
  
    * Add the following directories to your Matlab path using full path info.
	
	1. /njTBX-2.0
                2. /njTBX-2.0/Utilities
                3. /njFunc
                4. /RPSstuff
                5. /seawater

Step 4: Try examples!

    * Go to the NJ Toolbox examples directory ( ./examples, /examples/ugrid), and try the following:
    * do_interop.m Demonstrates reading several different structured (POM, ECOM, and ROMS) and unstructured grid 
      (FVCOM) model results with the exact same routine.  
       Doesn't make any fancy plots, but delivers 3D data fields with corrresponding lon,lat, z and time.
    * do_interop_plot3d.m Makes a 3D plot of the bottom temperature for structured grid models.
    * test_plot3D_fvcom.m Makes a 3D plot of bottom layer temperature for unstructured grid FVCOM model.
    * do_interop_data.m Compares an observed vertical profile of temperature to two different models.
    * gomoos_latest.m Plots a daily-averaged section of alongshore velocity from the latest GoMOOS forecast. 
    * do_interop_bot_temp.m Plots observed bottom temperatures within the last day on top of the predicted bottom temperature 
      from the GoMOOS forecast model.
    * bathy_comp.m Compare bathymetry from two different bathymetric grids (global or regional).
    * /ugrid/test_cf_ugrid.m  Read CF-UGRID convention data from ADCIRC, FVCOM and ELCIRC
    * You can also go to /njTBX-2.0/examples directory to checkout examples on API usage.

Step 5: Explore on your own!
  
    * The tools with "cf" are meant to be used with CF compliant data, while the tool "nj_varget" works with non-CF compliant data as well.   
       All the data on the Gulf of Maine Interoperability Experiment THREDDS Catalog at 
       http://coast-enviro.er.usgs.gov/thredds/gom_interop_catalog.html is CF-compliant.  Browse the catalog and then cut-n-paste 
       the OpenDAP URL into your matlab workspace to access that dataset. 
    * Explore bathymetry!  A collection of regional and global bathymetry (including the NOAA Coastal Relief Model) is available through this 
      THREDDS Catalog:
      http://coast-enviro.er.usgs.gov/thredds/bathy_catalog.html
      If you are on a PC, there is an extremely useful toolkit for bathymetry called Mirone, by Joachim Luis.  You can use the "cf_subsetGrid.m" 
      routine to clip just the region you want from a bathymetry data set.  For example:   
      >> uri='http://coast-enviro.er.usgs.gov/thredds/dodsC/bathy/crm_vol1.nc';
      >> [data,geo]=cf_subsetGrid(uri,'topo',[-70.9 -70.1 41.15 41.65]);
      will clip the bathy data from the Martha's Vineyard region out of the Coastal Relief Model Vol. 1 (Northeast) into your Matlab work space.   
     To make a simple plot, you can use "pcolor" or
      >> imagesc(geo.lon,geo.lat,data); axis xy
      To get the data into Mirone (Download Mirone from http://w3.ualg.pt/~jluis/mirone/), do:
      >> grid2mirone(data,geo)
      See the Mirone help for more information -- it's a very powerful tool with many capabilities, including profiles, color-shaded relief images, 
      output to Google Earth, the free Fledermaus IVIEW3D viewer, and more.
    * The NJ toolbox routines can access data from THREDDS catalogs and OpenDAP servers (as well as local and remote NetCDF files).  
       More sources of data can be found by searching for "thredds" or "opendap" at NASA's Global Change Master Directory (http://gcmd.nasa.gov)


Any questions ?

Email: Rich Signell (rsignell@usgs.gov) or Sachin Bhate (skbhate@ngi.msstate.edu)
           