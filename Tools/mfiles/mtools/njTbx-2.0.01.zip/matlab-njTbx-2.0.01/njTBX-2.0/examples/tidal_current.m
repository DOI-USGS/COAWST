% Example 

uri='http://oceanus.irb.hr/opendap/nph-dods/models/Adria_010_tide.nc';

disp(' ');
% Same example (as above) using netcdf-toolbox using mexnc
disp('Example: Netcdf-toolbox using mexnc (Figure-1) ....... please wait ...');
tic;
nc=netcdf(uri);
tri=nc{'tri'}(:); % grab element incidence list
lon=nc{'lon'}(:);
lat=nc{'lat'}(:);
%will use other data access method than (:)
harm_names=nc{'HARMONIC_NAMES'}(:);
ifreq=strmatch('M2',harm_names);
u=nc{'ELLIPSE_MAJOR'}(:,ifreq);
close(nc);

%plot results
figure(1);
trisurf(tri,lon,lat,u);view(2);
lat0=mean(lat(:));xfac=cos(lat0*pi/180);daspect([1 xfac 1]);
shading faceted;caxis([0 0.2]);axis([13.5 15 44.2 45.2]); colorbar;
toc;

% Example using MATLAB OOP using NETCDF-JAVA

disp('Example: Matlab OOP using Netcdf-Java (Figure-2) ....... please wait ...');
tic;
nc1=mDataset(uri);
tri1=nc1{'tri'}(:); % grab element incidence list
lon1=nc1{'lon'}(:);
lat1=nc1{'lat'}(:);
harm_names1=nc1{'HARMONIC_NAMES'}(:);  
ifreq1=strmatch('M2',harm_names1);  
u1=nc1{'ELLIPSE_MAJOR'}(:,ifreq1);   
close(nc1);

%plot results
figure(2);
trisurf(tri1,lon1,lat1,u1);view(2);
lat01=mean(lat1(:));xfac1=cos(lat01*pi/180);daspect([1 xfac1 1]);
shading faceted;caxis([0 0.2]);axis([13.5 15 44.2 45.2]); colorbar;
toc;

