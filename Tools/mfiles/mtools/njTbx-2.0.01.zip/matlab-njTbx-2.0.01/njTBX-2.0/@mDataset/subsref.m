function result = subsref(mDatasetObj, theStruct)

% mDataset/subsref -- Overloaded "{}", "()", and "." operators.
%  subsref(mDatasetObj, theStruct) processes subscripting references
%   of this, a "mDataset" object.
% 
% 
% Sachin Kumar Bhate (skbhate@ngi.msstate.edu) (C) 2008
% Mississippi State University

if nargin < 1, help(mfilename), return, end

result = [];
if (~isa(mDatasetObj, 'mDataset'))    
    error('MATLAB:mDataset:subsref',...
       'Invalid Object "%s".', class(mDatasetObj));                    
end
s = theStruct;
theType = s(1).type;
theSubs = s(1).subs;
s(1) = [];
% the sub can be a cell array ..but we need the value.

if isa(theSubs, 'cell')  
   theSubs = theSubs{1};
end

switch theType
    % DOT reference
      case '.'
        switch theSubs
            case 'getJDataset'                
                    result = getJDataset(mDatasetObj);
            case 'getAttributes'                
                    result = getAttributes(mDatasetObj);
            case 'getInfo'            
                result = getInfo(mDatasetObj);          
            case 'close'                                  
                    close(mDatasetObj);               
            otherwise
                error(['??? Reference to non-existent field ' theSubs '.']);
        end  
    %cell reference
      case '{}'
        switch class(theSubs)
            case 'char'
                myVar = theSubs;                
                    result = getVar(mDatasetObj, myVar);                
                %see if the variable object is ok or user needs data 
                 if ~isempty(result)        
                    result = subsref(result, s); %make mVariable/subsref call
                 end
       
            otherwise
                error(['??? Reference to non-existent field ' theSubs '.']);
        end  
    otherwise,
        warning('MATLAB:subsref', ...
                'Invalid index type, "%s".', theType)
 
end

end

