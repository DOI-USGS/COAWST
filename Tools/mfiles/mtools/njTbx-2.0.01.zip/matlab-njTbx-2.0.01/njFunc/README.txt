README: njTools/njFunc (beta)

The matlab functions in this directory are highlevel convenience functions which uses 
njTBX-2.0 matlab object API. 

Requirement:

1. Matlab version 2006 and later.
2. njTBX-2.0
2. njTools Java API vesion 2.0
3. Unidata's Necdf-Java API Version 4.0 (toolsUI-4.0-skb<version>.jar) 
4. Java version 1.6 or higher
   

any questions..
send email to skbhate@ngi.msstate.edu

-Sachin Bhate.
skbhate@ngi.msstate.edu
Copyright Mississippi State University

   

